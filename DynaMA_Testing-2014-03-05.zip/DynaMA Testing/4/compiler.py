import os,time,datetime

pcapDir = "/home/todd/Desktop/PacketShooter"

dirtyTimes = []
cleanTimes = []

shooterLog = os.path.join(pcapDir, 'trafficLog.txt')
dynamaLog = os.path.join(pcapDir, 'dynamaLog.txt')

with open(shooterLog,"r") as mfh:
	shooterLines = mfh.readlines()

with open(dynamaLog,"r") as mfh:
	dynamaLines = mfh.readlines()


for i in shooterLines:
	g = i.split(',')
	h = [datetime.datetime.strptime(g[0], "%Y-%m-%d %H:%M:%S.%f"),datetime.datetime.strptime(g[1], "%Y-%m-%d %H:%M:%S.%f"),g[2].rstrip()]
	if h[2] == "clean":
		cleanTimes.append([h[0],h[1]])
	else:
		dirtyTimes.append([h[0],h[1],h[2][-1]])

#Converted Dynama Log
CDL = []

for i in dynamaLines:
	g = i.split(',')
	CDL.append([datetime.datetime.strptime(g[0], "%Y-%m-%d %H:%M:%S.%f"),g[1].rstrip(),g[2].rstrip()])


#Format of CDL entries
#[datetime,flag,level]
#data_types => 
#[datetime.datetime,str,str]

#numDirty = len(dirtyTimes)*575
#numClean = len(cleanTimes)*4372
totalPackets = 0
for i in shooterLines:
	totalPackets+=int(i.split(",")[3].rstrip())

print totalPackets
#key:value
#dirty pcap: [freqcy,nameV]

flagDict = {"dirty1":[0,0],"dirty2":[0,0],"dirty3":[0,0],"dirty4":[0,0],"dirty5":[0,0],"falsePositive":[0,0]}#,"totalSent":totalPackets}

print cleanTimes

for i in CDL:
	for t in cleanTimes:
		if t[0] <= i[0] <= t[1]:
			if i[1]== "freqcy":
				flagDict["falsePositive"][0]+=1
			elif i[1]== "nameV":
				flagDict["falsePositive"][1]+=1

			
	for t in dirtyTimes:
		if t[0] <= i[0] <= t[1]:
			if i[1]== "freqcy":
				flagDict["dirty"+str(t[-1])][0]+=1
			elif i[1]== "nameV":
				flagDict["dirty"+str(t[-1])][1]+=1



print flagDict


#http://docs.python.org/library/time.html#time.strptime

