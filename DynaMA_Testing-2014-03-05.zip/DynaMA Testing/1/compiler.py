import os,time,datetime

pcapDir = r"C:\Users\x41972\Google Drive\Crimeware\Dynama Test 1"

dirtyTimes = []
cleanTimes = []

shooterLog = os.path.join(pcapDir, 'trafficLog.txt')
dynamaLog = os.path.join(pcapDir, 'dynamaLog.txt')

with open(shooterLog,"r") as mfh:
	shooterLines = mfh.readlines()

with open(dynamaLog,"r") as mfh:
	dynamaLines = mfh.readlines()

shooterList = []
for i in shooterLines:
	g = i.split(',')
	h = [datetime.datetime.strptime(g[0], "%Y-%m-%d %H:%M:%S.%f"),datetime.datetime.strptime(g[1], "%Y-%m-%d %H:%M:%S.%f"),g[2].rstrip()]
	if h[2] == "clean":
		cleanTimes.append([h[0],h[1]])
	elif h[2] == "dirty":
		dirtyTimes.append([h[0],h[1]])

#Converted Dynama Log
CDL = []

for i in dynamaLines:
	g = i.split(',')
	CDL.append([datetime.datetime.strptime(g[0], "%Y-%m-%d %H:%M:%S.%f"),g[1].rstrip(),g[2].rstrip()])

print len(CDL)

#Format of CDL entries
#[datetime,flag,level]
#data_types => 
#[datetime.datetime,str,str]

numDirty = len(dirtyTimes)*575
numClean = len(cleanTimes)*4372
totalPackets = numClean + numDirty

flagDict = {"freqcy":0,"nameV":0,"falsePositiveNameV":0,"totalSent":totalPackets}

for i in CDL:
	for t in cleanTimes:
		if t[0] <= i[0] <= t[1]:
			#if i[1]== "nameV":
			flagDict["falsePositiveNameV"]+=1
			
	for t in dirtyTimes:
		if t[0] <= i[0] <= t[1]:
			if i[1] == "freqcy":
				flagDict["freqcy"]+=1
			elif i[1] == "nameV":
				flagDict["nameV"]+=1





print flagDict


#http://docs.python.org/library/time.html#time.strptime

