#Builds and sends DNS packet to test Dynama
from scapy.all import *
import os.path, time, datetime
import logging

pcapDir = "/home/todd/Desktop/PacketShooter"


log = os.path.join(pcapDir, 'trafficLog.txt')

loops = 0

##Loops through our pcap files and sends dns packets on the wire
def looper(signal):
	global loops
	print loops

	counter = 0
	if signal == 0:
		path = os.path.join(pcapDir, 'signals/clean.pcap')
	elif signal >0:
		path = os.path.join(pcapDir, 'signals/dirty'+str(signal)+'.pcap')
		#1=> CryptoLocker
		#2=> torPigMiniLoader
		#3=> bitCoinMiner
		#4=> DNSChanger 

		
#choose filename instead to loop through the directory
        pfile = os.path.join(path)
        pcap = rdpcap(pfile)
	print len(pcap)
#Loops through the packets in a file
	startTime = datetime.datetime.now() 
	for packet in pcap:
#searches for DNS packets and sends all (4372) => 10 seconds each => 
		#time.sleep(.20)
        	if 'Proto=DNS' or 'proto=dns' in packet:
                        try:
                        	global counter
				sendp(packet)
				counter+=1
				print str(loops)+"."+str(counter)
                       	except:
                                pass
	time.sleep(30)
	endTime = datetime.datetime.now()
	print counter
	with open(log,"a") as mfh:
		if signal == 0:
			mfh.write(str(startTime)+","+str(endTime)+",clean,"+str(counter)+"\n")
			print "writing clean log"
		elif signal >0:
			mfh.write(str(startTime)+","+str(endTime)+",dirty"+str(signal)+","+str(counter)+"\n")
			print "writing dirty log"
	loops+=1

def main():
	#this will run for
	dirtyNum = 1
	while loops < 600:
		looper(0)#clean
		looper(dirtyNum)#dirty
		if dirtyNum == 4:
			dirtyNum = 1
		else:
			dirtyNum+=1
		

main()


