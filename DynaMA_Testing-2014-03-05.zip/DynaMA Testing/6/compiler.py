import os,time,datetime

pcapDir = "/home/todd/Desktop/PacketShooter"

dirtyTimes = []
cleanTimes = []

shooterLog = os.path.join(pcapDir, 'trafficLog.txt')
dynamaLog = os.path.join(pcapDir, 'dynamaLog.txt')

with open(shooterLog,"r") as mfh:
	shooterLines = mfh.readlines()

with open(dynamaLog,"r") as mfh:
	dynamaLines = mfh.readlines()



flagDict = {"dirty1":[0,0,0],"dirty2":[0,0,0],"dirty3":[0,0,0],"dirty4":[0,0,0],"clean":[0,0,0]}#,"totalSent":totalPackets}

for i in shooterLines:
	g = i.split(',')
	h = [datetime.datetime.strptime(g[0], "%Y-%m-%d %H:%M:%S.%f"),datetime.datetime.strptime(g[1], "%Y-%m-%d %H:%M:%S.%f"),g[2].rstrip()]
	if h[2] == "clean":
		cleanTimes.append([h[0],h[1]])
		flagDict["clean"][2]+=1
	else:
		dirtyTimes.append([h[0],h[1],h[2][-1]])
		flagDict["dirty"+str(h[2][-1])][2]+=1

print flagDict

#Converted Dynama Log
CDL = []

for i in dynamaLines:
	g = i.split(',')
	CDL.append([datetime.datetime.strptime(g[0], "%Y-%m-%d %H:%M:%S.%f"),g[1].rstrip(),g[2].rstrip()])


#Format of CDL entries
#[datetime,flag,level]
#data_types => 
#[datetime.datetime,str,str]

#numDirty = len(dirtyTimes)*575
#numClean = len(cleanTimes)*4372
totalPackets = 0
for i in shooterLines:
	totalPackets+=int(i.split(",")[3].rstrip())


#print totalPackets
#key:value
#dirty pcap: [freqcy,nameV]



#print cleanTimes

for i in CDL:
	for t in cleanTimes:
		if t[0] <= i[0] <= t[1]:
			if i[1]== "freqcy":
				flagDict["clean"][0]+=1
			elif i[1]== "nameV":
				flagDict["clean"][1]+=1

	for t in dirtyTimes:
		if t[0] <= i[0] <= t[1]:
			if i[1]== "freqcy":
				flagDict["dirty"+str(t[-1])][0]+=1
			elif i[1]== "nameV":
				flagDict["dirty"+str(t[-1])][1]+=1



print flagDict

output = os.path.join(pcapDir, 'outputAnalytics.csv')

with open(output,"a") as mfh:
	mfh.write("Test: ,Sent,Freqcy,NameV,Flags Returned,Flags Expected\n")
	#Clean
	mfh.write("Clean,"+str(flagDict["clean"][2]*1657)+","+str(flagDict["clean"][0])+","+str(flagDict["clean"][1])+","+str(flagDict["clean"][0]+flagDict["clean"][1])+","+str(flagDict["clean"][2]*0)+"\n")
	#CryptoLocker
	mfh.write("CryptoLocker,"+str(flagDict["dirty1"][2]*524)+","+str(flagDict["dirty1"][0])+","+str(flagDict["dirty1"][1])+","+str(flagDict["dirty1"][0]+flagDict["dirty1"][1])+","+str(flagDict["dirty1"][2]*513)+"\n")
	#torPigMiniLoader
	mfh.write("TorPig,"+str(flagDict["dirty2"][2]*362)+","+str(flagDict["dirty2"][0])+","+str(flagDict["dirty2"][1])+","+str(flagDict["dirty2"][0]+flagDict["dirty2"][1])+","+str(flagDict["dirty2"][2]*94)+"\n")
	#bitCoinMiner
	mfh.write("bitCoinMiner,"+str(flagDict["dirty3"][2]*4)+","+str(flagDict["dirty3"][0])+","+str(flagDict["dirty3"][1])+","+str(flagDict["dirty3"][0]+flagDict["dirty3"][1])+","+str(flagDict["dirty3"][2]*4)+"\n")

	#DNSChanger
	mfh.write("DNSChanger,"+str(flagDict["dirty4"][2]*13)+","+str(flagDict["dirty4"][0])+","+str(flagDict["dirty4"][1])+","+str(flagDict["dirty4"][0]+flagDict["dirty4"][1])+","+str(flagDict["dirty4"][2]*13)+"\n \n \n ")


#http://docs.python.org/library/time.html#time.strptime

